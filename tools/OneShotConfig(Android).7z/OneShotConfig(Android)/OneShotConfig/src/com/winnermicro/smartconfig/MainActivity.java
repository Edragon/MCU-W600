package com.winnermicro.smartconfig;

import java.io.IOException;
import java.lang.reflect.Method;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.net.wifi.ScanResult;
import android.net.wifi.WifiConfiguration;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {

	public static final int TYPE_NO_PASSWD = 0x11;
	public static final int TYPE_WEP = 0x12;
	public static final int TYPE_WPA = 0x13;
	    
	private Button btnConf;
	//private TextView textSsid;
	private TextView text_total;
	private Spinner mySpinner;
	private EditText editPsw;
	private Handler handler = new Handler();
	private boolean isStart = false;
	private String psw = null;
	private ISmartConfig smartConfig = null;
	private Boolean isThreadDisable = false;//ָʾ�����߳��Ƿ���ֹ
	private List<String> lstMac = new ArrayList<String>();
	private List<String> listSsid = new ArrayList<String>();  
	private ArrayAdapter<String> adapterSsid; 
	private UdpHelper udphelper;
	private Thread tReceived;
	private ListView listView;
	private int errorId = 0;
	private ResultAdapter adapter = null;
	private SmartConfigFactory factory = null;
	private HashMap<String, String> hashmap = new HashMap<String, String>();  
	private HashMap<String, Integer> hashmapSecurity = new HashMap<String, Integer>();  
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		btnConf = (Button)findViewById(R.id.btn_conf);
		btnConf.setOnClickListener(onButtonConfClick);
		//textSsid = (TextView)findViewById(R.id.text_ssid);
		text_total = (TextView) findViewById(R.id.text_total);
		mySpinner = (Spinner)findViewById(R.id.text_ssid);  
		adapterSsid = new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item, listSsid);    
		adapterSsid.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		mySpinner.setAdapter(adapterSsid); 
		mySpinner.setEnabled(false);
		
		editPsw = (EditText) findViewById(R.id.text_psw);
		listView = (ListView) findViewById(R.id.listView1);
		
        
		factory = new SmartConfigFactory();
		//ͨ���޸Ĳ���ConfigType��ȷ��ʹ�ú��ַ�ʽ����һ�����ã���Ҫ�͹̼��ౣ��һ�¡�
		smartConfig = factory.createSmartConfig(ConfigType.UDP, this);
		/*�Զ���������
		hashmap.put("ASUS-N10E", "Fas890&*(");
		hashmap.put("Xiaomi_mini", "J43P      !\\$");
		hashmap.put("UTT", "Cnak5_=2|454@#$^");
		hashmap.put("Netcore", "ABCDE12345");
		hashmap.put("ChinaNet-huawei", "387@~!#+)&**(");
		hashmap.put("Wavlink", "&*[]<>,.");
		hashmap.put("fast", "L137j898-90'/-\"0=.?");
		hashmap.put("HiWiFi", "-612,3849739\" $%^&&*())__++*^%$$$#$%?:");
		hashmap.put("Xiaomi", "78O0()?>");
		hashmap.put("TOTOLINK", "?.,;_-+()#$@&*()p98?745M112sajdfkha");
		hashmap.put("H3C", "Euru&*((457");
		hashmap.put("Tenda", "Dsaf 78_");
		hashmap.put("TP-LINK", "\"\\ds'/\\?:}{7Q");
		hashmap.put("Cisco", "Fjsajdfsaj72389\"1472^%&()_(**^&%$*&^$");
		hashmap.put("JCG", "738947yuYU%^%(*)_%^^(*%$");
		hashmap.put("BELKIN", "Dfasdfas-\38r4783975?>:{})(&^$#@@#%^&^");
		hashmap.put("MECURY", "746246df|\\/'ihsfakjh&*()T$EWE&");
		hashmap.put("NETGEAR", "2378y624389902Y43\\|%^&&*&*%$^$$^");
		hashmap.put("HP", "lsd_1234567890abc");
		hashmap.put("D-Link", "4378}pr$!~#%^<>?P");
		hashmap.put("ZTE", "52E7^&**(\'VMK,V");
		hashmap.put("Mywifi-12441A", "389DS<>?:UJUIEkfj745");
		hashmap.put("newifi_7DD4", "ABCDE123");
		hashmap.put("FYX", "23782?><:.;,");
		hashmap.put("Apple Network", "!@#$%^&*()_+_~`\\|/.,");
		*/
		

		mySpinner
				.setOnItemSelectedListener(new Spinner.OnItemSelectedListener() {
					public void onItemSelected(AdapterView<?> arg0, View arg1,
							int arg2, long arg3) {
						String ssid = mySpinner.getSelectedItem().toString();
						String psw = hashmap.get(ssid);
						WifiManager wifiManager = (WifiManager) getSystemService(Context.WIFI_SERVICE);
						if(wifiManager.isWifiEnabled() && psw != null){
							
							String ssidFormat = "\"%s\"";
							String ssidf = String.format(ssidFormat, ssid);
							int nId = -1;
							for(WifiConfiguration wifiConf : wifiManager.getConfiguredNetworks()){
								if(wifiConf.SSID.equals(ssidf)){
									nId = wifiConf.networkId;
									break;
								}
							}
							String ssidString=null;
							WifiInfo wifiInfo = wifiManager.getConnectionInfo();
							if(wifiInfo != null){
								ssidString=wifiInfo.getSSID();
								int version = getAndroidSDKVersion();
								if(version > 16 && ssidString.startsWith("\"") && ssidString.endsWith("\"")){
									ssidString = ssidString.substring(1, ssidString.length() - 1);
								}
							}
							if(nId == -1){
								WifiConfiguration wifiConfig = createWifiInfo(ssid, psw, 
										hashmapSecurity.get(ssid) == null ? TYPE_WPA : hashmapSecurity.get(ssid).intValue());
								nId = wifiManager.addNetwork(wifiConfig);
								wifiManager.saveConfiguration();
							}
							if(nId>0 && !ssid.equals(ssidString)){
								wifiManager.enableNetwork(nId, true);
							}
						}
						editPsw.setText(psw);
						arg0.setVisibility(View.VISIBLE);
					}

					public void onNothingSelected(AdapterView<?> arg0) {
						editPsw.setText("");
						arg0.setVisibility(View.VISIBLE);
					}
				});
	}
	
	@Override
	protected void onStop() {
		super.onStop();
		stopConfig();
	}

	public WifiConfiguration createWifiInfo(String SSID, String password, int type) {  
          
        WifiConfiguration config = new WifiConfiguration();  
        config.allowedAuthAlgorithms.clear();  
        config.allowedGroupCiphers.clear();  
        config.allowedKeyManagement.clear();  
        config.allowedPairwiseCiphers.clear();  
        config.allowedProtocols.clear();  
        config.SSID = "\"" + SSID + "\"";  
            
        // ��Ϊ���������1û������2��wep����3��wpa����  
        if (type == TYPE_NO_PASSWD) {// WIFICIPHER_NOPASS  
            config.wepKeys[0] = "";  
            config.allowedKeyManagement.set(WifiConfiguration.KeyMgmt.NONE);  
            config.wepTxKeyIndex = 0;  
              
        } else if (type == TYPE_WEP) {  //  WIFICIPHER_WEP   
            config.hiddenSSID = true;  
            config.wepKeys[0] = "\"" + password + "\"";  
            config.allowedAuthAlgorithms  
                    .set(WifiConfiguration.AuthAlgorithm.SHARED);  
            config.allowedGroupCiphers.set(WifiConfiguration.GroupCipher.CCMP);  
            config.allowedGroupCiphers.set(WifiConfiguration.GroupCipher.TKIP);  
            config.allowedGroupCiphers.set(WifiConfiguration.GroupCipher.WEP40);  
            config.allowedGroupCiphers  
                    .set(WifiConfiguration.GroupCipher.WEP104);  
            config.allowedKeyManagement.set(WifiConfiguration.KeyMgmt.NONE);  
            config.wepTxKeyIndex = 0;  
        } else if (type == TYPE_WPA) {   // WIFICIPHER_WPA  
            config.preSharedKey = "\"" + password + "\"";  
            config.hiddenSSID = true;  
            config.allowedAuthAlgorithms  
                    .set(WifiConfiguration.AuthAlgorithm.OPEN);  
            config.allowedGroupCiphers.set(WifiConfiguration.GroupCipher.TKIP);  
            config.allowedKeyManagement.set(WifiConfiguration.KeyMgmt.WPA_PSK);  
            config.allowedPairwiseCiphers  
                    .set(WifiConfiguration.PairwiseCipher.TKIP);  
            // config.allowedProtocols.set(WifiConfiguration.Protocol.WPA);  
            config.allowedGroupCiphers.set(WifiConfiguration.GroupCipher.CCMP);  
            config.allowedPairwiseCiphers  
                    .set(WifiConfiguration.PairwiseCipher.CCMP);  
            config.status = WifiConfiguration.Status.ENABLED;  
        }   
          
        return config;  
    }  

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}
	
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {

		case R.id.action_custom:

			// ��action bar���app icon; �ص� home

			Intent intent = new Intent(this, CusDataActivity.class);

			intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);

			startActivity(intent);

			return true;
		case R.id.action_get_ver:
			String ver = factory.getVersion();
			Toast.makeText(this, "SDK ver " + ver, Toast.LENGTH_SHORT).show();
			break;
		default:
			break;
		}
		return super.onOptionsItemSelected(item);
	}
	
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if(keyCode == KeyEvent.KEYCODE_BACK) {
			if(isStart){
				stopConfig();
			}
		}
		return super.onKeyDown(keyCode, event);
	}
	private void setEditable(boolean value) {
		if (value) {
			/*editPsw.setFilters(new InputFilter[] { new InputFilter() {
				public CharSequence filter(CharSequence source, int start,
						int end, Spanned dest, int dstart, int dend) {
					return null;
				}
			} });*/
			editPsw.setCursorVisible(true);
			editPsw.setFocusable(true);     
			editPsw.setFocusableInTouchMode(true);
			editPsw.requestFocus();
		} else {
			/*
			editPsw.setFilters(new InputFilter[] { new InputFilter() {
				@Override
				public CharSequence filter(CharSequence source, int start,
						int end, Spanned dest, int dstart, int dend) {
					return source.length() < 1 ? dest.subSequence(dstart, dend)
							: "";
				}

			} });*/
			editPsw.setCursorVisible(false);
			editPsw.setFocusable(false);  
			editPsw.setFocusableInTouchMode(false);
			editPsw.clearFocus();
		}
	}
	private void stopConfig(){
		isThreadDisable = true;
		if(isStart){
			isStart = false;
			btnConf.setEnabled(false);
		}
		smartConfig.stopConfig();
	}
	private int getAndroidSDKVersion() { 
		int version = 0;
		try {
			version = Integer.valueOf(android.os.Build.VERSION.SDK_INT);
		} catch (NumberFormatException e) {
			Log.e(e.toString(), e.getMessage());
		}
		return version;
	}
	
	/**
	 * 
	 * 
	 * 
	 * ���豸������Ϣ�иĶ���������Ļ����ĸı䣬ʵ����̵��ƿ�����ϵȣ�ʱ��
	 * 
	 * ���������ʱ��activity�������У�ϵͳ��������������
	 * 
	 * ע�⣺onConfigurationChangedֻ����Ӧ�ó�����AnroidMainifest.xml��ͨ��
	 * 
	 * android:configChanges="xxxx"ָ�����������͵ĸĶ���
	 * 
	 * �������������õĸ��ģ���ϵͳ��onDestroy()��ǰActivity��Ȼ������һ���µ�Activityʵ����
	 */

	@Override
	public void onConfigurationChanged(Configuration newConfig) {

		super.onConfigurationChanged(newConfig);

		// �����Ļ�ķ�����������

		if (this.getResources().getConfiguration().orientation

		== Configuration.ORIENTATION_LANDSCAPE) {

			// ��ǰΪ������ �ڴ˴����Ӷ���Ĵ�������

		} else if (this.getResources().getConfiguration().orientation == Configuration.ORIENTATION_PORTRAIT) {

			// ��ǰΪ������ �ڴ˴����Ӷ���Ĵ�������

		}

		// ���ʵ����̵�״̬���Ƴ����ߺ���

		if (newConfig.hardKeyboardHidden

		== Configuration.HARDKEYBOARDHIDDEN_NO) {

			// ʵ����̴����Ƴ�״̬���ڴ˴����Ӷ���Ĵ�������
		} else if (newConfig.hardKeyboardHidden == Configuration.HARDKEYBOARDHIDDEN_YES) {
			// ʵ����̴��ں���״̬���ڴ˴����Ӷ���Ĵ�������
		}
	}
	
	/**�ж��ȵ㿪��״̬*/
	public boolean isWifiApEnabled() {
		return getWifiApState() == WIFI_AP_STATE.WIFI_AP_STATE_ENABLED;
	}

	private WIFI_AP_STATE getWifiApState(){
		int tmp;
		WifiManager wifiManager = (WifiManager) getSystemService(WIFI_SERVICE);
		try {
			Method method = wifiManager.getClass().getMethod("getWifiApState");
			tmp = ((Integer) method.invoke(wifiManager));
			// Fix for Android 4
			if (tmp > 10) {
				tmp = tmp - 10;
			}
			return WIFI_AP_STATE.class.getEnumConstants()[tmp];
		} catch (Exception e) {
			e.printStackTrace();
			return WIFI_AP_STATE.WIFI_AP_STATE_FAILED;
		}
	}
	
	private WifiConfiguration getWifiApConfiguration(){
		WifiManager wifiManager = (WifiManager) getSystemService(WIFI_SERVICE);
		try {
			Method method = wifiManager.getClass().getMethod("getWifiApConfiguration");
			WifiConfiguration tmp = ((WifiConfiguration) method.invoke(wifiManager));
			
			return tmp;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	public enum WIFI_AP_STATE {
		WIFI_AP_STATE_DISABLING, WIFI_AP_STATE_DISABLED, WIFI_AP_STATE_ENABLING,  WIFI_AP_STATE_ENABLED, WIFI_AP_STATE_FAILED
	}
	
	@Override
	protected void onStart()
	{
		super.onStart();
		try {
			WifiManager wifiManager = (WifiManager) getSystemService(WIFI_SERVICE);  
			if(wifiManager.isWifiEnabled())
			{
				int position = 0;
				listSsid.clear();
				hashmapSecurity.clear();
				List<ScanResult> scanResults = wifiManager.getScanResults();
				for(ScanResult r : scanResults){
					listSsid.add(r.SSID);
					int sec = TYPE_WPA;
					if (r.capabilities.contains("WPA")
							|| r.capabilities.contains("wpa")) {
						sec = TYPE_WPA;
					} else if (r.capabilities.contains("WEP")
							|| r.capabilities.contains("wep")) {
						sec = TYPE_WEP;
					} else {
						sec = TYPE_NO_PASSWD;
					}
					hashmapSecurity.put(r.SSID, sec);
				}
				adapterSsid.notifyDataSetChanged();
				WifiInfo wifiInfo = wifiManager.getConnectionInfo();
				String ssidString=null;
				if(wifiInfo != null){
					ssidString=wifiInfo.getSSID();
					int version = getAndroidSDKVersion();
					if(version > 16 && ssidString.startsWith("\"") && ssidString.endsWith("\"")){
						ssidString = ssidString.substring(1, ssidString.length() - 1);
					}	
					for(;position < listSsid.size(); position++){
						if(ssidString == null || ssidString.endsWith(listSsid.get(position))){
							break;
						}
					}
				}
				mySpinner.setSelection(position);
				if(position == 0){
					displayToast(ssidString==null?"null":ssidString);
				}
			}
			else if(isWifiApEnabled())
			{
				int position = 0;
				listSsid.clear();
				hashmapSecurity.clear();
				WifiConfiguration conf = getWifiApConfiguration();
				String ssidString=null;
				if(conf != null){
					ssidString = conf.SSID;
					listSsid.add(ssidString);
					adapterSsid.notifyDataSetChanged();
					for(;position < listSsid.size(); position++){
						if(ssidString == null || ssidString.endsWith(listSsid.get(position))){
							break;
						}
					}
				}
				mySpinner.setSelection(position);
				if(position == 0){
					displayToast(ssidString==null?"null":ssidString);
				}
			}
			else
			{
				displayToast("���粻���ã���������!");
			}
			adapter = new ResultAdapter(this, android.R.layout.simple_expandable_list_item_1, lstMac);
			listView.setAdapter(adapter);
		} catch (Exception e) {
			e.printStackTrace();
		}		
	}
	@Override
	protected void onDestroy() {
		super.onDestroy();
		handler.removeCallbacks(confPost);
	}
	public void displayToast(String str)
	{
		Toast.makeText(this, str, Toast.LENGTH_SHORT).show();
	}
    
	private OnClickListener onButtonConfClick = new OnClickListener(){

		@Override
		public void onClick(View v) {
			if(isStart){
				stopConfig();
				return;
			}
			/*String ssid = mySpinner.getSelectedItem().toString();
			if(ssid.length() == 0){
				displayToast("��������WIFI����!");
				return;
			}*/
			errorId = 0;
			psw = editPsw.getText().toString();
			lstMac.clear();
			adapter.notifyDataSetChanged();
			isStart = true;
			isThreadDisable = false;
			setEditable(false);
			WifiManager wifiManager = (WifiManager) getSystemService(WIFI_SERVICE);
			udphelper = new UdpHelper(wifiManager);
			tReceived = new Thread(udphelper);
	        tReceived.start();
			new Thread(new UDPReqThread()).start();
			text_total.setText(String.format("%d connected.", lstMac.size()));
			btnConf.setText(getText(R.string.btn_stop_conf));
		}
	};
	
	private Runnable confPost = new Runnable(){
		
		@Override
		public void run() {
			isStart=false;
			isThreadDisable = true;
			btnConf.setEnabled(true);
			setEditable(true);
			btnConf.setText(getText(R.string.btn_conf));
			if(adapter != null){
				adapter.notifyDataSetChanged();
			}	
			smartConfig.stopConfig();
			if(errorId == OneShotException.ERROR_NETWORK_NOT_SUPPORT){
				Toast.makeText(getApplicationContext(), "��֧�ָ�����!",
						Toast.LENGTH_SHORT).show();
			}
			else if(errorId == OneShotException.ERROR_NETWORK_DISCONNECTED){
				Toast.makeText(getApplicationContext(), "���������ѶϿ�!",
						Toast.LENGTH_SHORT).show();
			}
			errorId = 0;
		}
		
	};
	
	private Runnable notifyPost = new Runnable(){
		
		@Override
		public void run() {
			//if(adapter != null){
			//	adapter.notifyDataSetChanged();
			//}
			text_total.setText(String.format("%d connected.", lstMac.size()));
			//Toast.makeText(getApplicationContext(), String.format("%d connected.", lstMac.size()),
			//		Toast.LENGTH_SHORT).show();
		}
		
	};
	class UDPReqThread implements Runnable {
		public void run() {
			WifiManager wifiManager = null;
			errorId = 0;
			try {
				wifiManager = (WifiManager) getSystemService(WIFI_SERVICE);  
				if(wifiManager.isWifiEnabled() || isWifiApEnabled())
				{
					while(isStart){
						if(smartConfig.startConfig(psw) == false)
						{
							Log.d("UDP Demo", "startConfig false");
							break;
						}
						Log.d("UDP Demo", "startConfig");
						Thread.sleep(10);
					}
				}
			}
			catch (OneShotException oe) {
				oe.printStackTrace();
				errorId = oe.getErrorID();
				if(oe.getErrorID() == OneShotException.ERROR_NETWORK_NOT_SUPPORT){
					//displayToast("��֧�ָ�����!");
				}
			} 
			catch (Exception e) {
				e.printStackTrace();
			}
			finally{
				handler.post(confPost);
			}
		}
		
	}
	
	@SuppressLint("DefaultLocale")
	class UdpHelper implements Runnable {

	    private WifiManager.MulticastLock lock;
	    InetAddress mInetAddress;
	    public UdpHelper(WifiManager manager) {
	         this.lock= manager.createMulticastLock("UDPwifi"); 
	    }
	    public void StartListen()  {
	        // UDP�����������Ķ˿�
	        Integer port = 65534;
	        // ���յ��ֽڴ�С���ͻ��˷��͵����ݲ��ܳ��������С
	        byte[] message = new byte[100];
	        try {
	            // ����Socket����
	            DatagramSocket datagramSocket = new DatagramSocket(port);
	            datagramSocket.setBroadcast(true);
	            datagramSocket.setSoTimeout(1000);
	            DatagramPacket datagramPacket = new DatagramPacket(message,
	                    message.length);
	            try {
	                while (!isThreadDisable) {
	                    // ׼����������
	                    Log.d("UDP Demo", "׼������");
	                    this.lock.acquire();
	                    try{
		                    datagramSocket.receive(datagramPacket);
		                    String strMsg="";
		                    int count = datagramPacket.getLength();
		                    for(int i=0;i<count;i++){
		                    	strMsg += String.format("%02x", datagramPacket.getData()[i]);
		                    }
		                    strMsg = strMsg.toUpperCase() + ";" + datagramPacket.getAddress().getHostAddress().toString();
		                    if(!lstMac.contains(strMsg)){
		                    	lstMac.add(strMsg);
		                    	handler.post(notifyPost);
		                    }
		                    Log.d("UDP Demo", datagramPacket.getAddress()
		                            .getHostAddress().toString()
		                            + ":" +strMsg );
		                    }
	                    catch(SocketTimeoutException ex){
	                    	Log.d("UDP Demo", "UDP Receive Timeout.");
	                    }
	                    this.lock.release();
	                }
	            } catch (IOException e) {//IOException
	                e.printStackTrace();
	            }
	            datagramSocket.close();
	        } catch (SocketException e) {
	            e.printStackTrace();
	        }
	        finally{
	        	if(!isThreadDisable){
	        		handler.post(confPost);
	        	}
	        }
	    }
		@Override
		public void run() {
			StartListen();
		}

	}
}
