//
//  AppDelegate.h
//  OneShotConfig
//
//  Created by codebat on 15/1/22.
//  Copyright (c) 2015年 Winnermicro. All rights reserved.
//


#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) NSTimer *timer;

@property (copy, nonatomic) NSString *Musername;

@property (copy, nonatomic) NSString *Mpasswd;

@end

