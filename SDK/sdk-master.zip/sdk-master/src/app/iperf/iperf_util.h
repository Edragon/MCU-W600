/*
 * Copyright (c) 2009-2011, The Regents of the University of California,
 * through Lawrence Berkeley National Laboratory (subject to receipt of any
 * required approvals from the U.S. Dept. of Energy).  All rights reserved.
 *
 * This code is distributed under a BSD style license, see the LICENSE file
 * for complete information.
 */

#ifndef __IPERF_UTIL_H
#define __IPERF_UTIL_H

void get_uuid(char *);

int is_closed(int);

void make_cookie(char *cookie);
#endif
