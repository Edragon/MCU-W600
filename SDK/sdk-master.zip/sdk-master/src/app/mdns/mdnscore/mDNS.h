#ifndef __MDNS_H_
#define __MDNS_H_

#define CLIENT_PROGRAM "mDNSClient"
#define MDNS_RECORD_PRE "/tmp/mdns."

#endif
