## W600 pwm example

W600 breathing led using hardware pwm.

Step 0: Compile and Download

``` 
wch@wch-pc /cygdrive/d/Project/sdk/example
$ ./build.sh pwm flash COM3

start...

```

Step 1 :  UART0   Printf

```
w600 pwm example, compile @Apr 23 2019 16:44:22
pwm task start ...

```
You can also see the LED on the development board breathing ...

### About

Please visit www.thingsturn.com or contact support@thingsturn.com
