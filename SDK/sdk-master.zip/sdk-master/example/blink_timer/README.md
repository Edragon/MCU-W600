## W600 blink timer example

W600 blink led using a hardware timer.

Step 0: Compile and Download

``` 
wch@wch-pc /cygdrive/d/Project/sdk/example
$ ./build.sh blink_timer flash COM3

start...

```

Step 1 :  UART0   Printf

```
w600 blink timer example, compile @Apr 23 2019 16:02:30
blink timer start
blink timer stop

```
You can also see the LED on the development board flashing ...

### About

Please visit www.thingsturn.com or contact support@thingsturn.com
