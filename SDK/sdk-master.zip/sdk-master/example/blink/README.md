## W600 blink example

W600 blink led using a task.

Step 0: Compile and Download

``` 
wch@wch-pc /cygdrive/d/Project/sdk/example
$ ./build.sh blink flash COM3

start...

```

Step 1 :  UART0   Printf

```
w600 blink example, compile @Apr 23 2019 16:02:30
blink task start ...

```
You can also see the LED on the development board flashing ...

### About

Please visit www.thingsturn.com or contact support@thingsturn.com
