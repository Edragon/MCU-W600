## W600 hello world example

W600 printf hello world using a task.

Step 0: Compile and Download

``` 
wch@wch-pc /cygdrive/d/Project/sdk/example
$ ./build.sh helloworld flash COM3

start...

```

Step 1 :  UART0   Printf

```
w600 hello world example, compile @Apr 23 2019 16:02:30
hello world!
hello world!
hello world!

```

### About

Please visit www.thingsturn.com or contact support@thingsturn.com
