# OneShot 开发

安卓源码：https://github.com/w600/OneShotForAndroid

iOS源码：https://github.com/w600/OneShotForIOS

APK下载：https://download.w600.fun/tool/OneShotConfig.apk

